package mywkpanorama.lugar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
