package mywkpanorama.lugar.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Response {
    private Integer code;
    private String message;



}
